/* user program to exercise these implementations and see how they work*/
// including the libraries
#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    printf(1, "Priority of main process is being set to 8...\n");
    int prio_num = 8;
    setPriority(&prio_num);

    int n = 10;

    int pid;

    pid = fork();

    if(pid < 0)
    {
        printf(1, "Fork1 failed\n");
    }
    else if(pid == 0)
    {
        printf(1, "Child1 Process...\n");
        printf(1, "Priority is being set to 4...\n");
        prio_num = 4;
        setPriority(&prio_num);
        printf(1, "%d", n);
        while(n > 1)
        {
            if(n % 2 == 0)
                n = n / 2;
            else
                n = 3 * n + 1;
            printf(1, ", %d", n);
        }
        printf(1, "\n");

        printf(1, "...Child1 Process Completed\n");

        int pid1 = fork();

        if(pid1 < 0)
        {
            printf(1, "Fork2 failed\n");
        }
        else if(pid1 == 0)
        {
            printf(1, "Child2 Process...\n");
            printf(1, "Priority is being set to 6...\n");
            prio_num = 6;
            setPriority(&prio_num);
            printf(1, "%d", n);
            while(n > 1)
            {
                if(n % 2 == 0)
                    n = n / 2;
                else
                    n = n - 1;
                printf(1, ", %d", n);
            }
            printf(1, "\n");

            printf(1, "...Child2 Process Completed\n");
        }
        else
        {
            wait();
            printf(1, "Parent2 Process...\n");
            printf(1, "The value of n: %d\n", n);
            printf(1, "...Parent2 Process Completed\n");
        }
    }
    else
    {
        wait();
        printf(1, "Parent1 Process...\n");
        printf(1, "The value of n: %d\n", n);
        printf(1, "...Parent1 Process Completed\n");
    }

    exit();
}