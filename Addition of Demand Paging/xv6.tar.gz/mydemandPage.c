/* user program to exercise this condition and see that
 * our simpler version of demand paging is working.
 * This use a large size global array and write/read from
 * this array to check for functioning of demand paging
 * Also, invokes pgPrint system call intermittently to check
 * that the page table is expanding as per demand paging
 */

#include "types.h"
#include "stat.h"
#include "user.h"

#define N 3000          /* global array size - change to see
                            the effect. Try 300, 5000, 10000 */
// declaring a global array
int glob[N];
int main()
{
    glob[0] = 8;    // initialize with any integer value
    printf(1, "global addr from user space: %x\n", glob);
    for(int i = 1; i < N; i++)
    {
        glob[i] = glob[i - 1];
        if(i % 1000 == 0)
            pgtPrint(); /* printing page entries after every 1000 
                            iterations */
    }
    printf(1, "Printing final page table:\n");
    pgtPrint(); // printing the page entries in final state
    printf(1, "Value: %d\n", glob[N - 1]);

    exit();
}