#include "types.h"
#include "user.h"

/* declared global array to check the effect on paging */
// int arrGlobal[10000];

int main(int argc, char *argv[])
{
    /* declared local array to check the effect on paging */
    // int arrLocal[10000];

    // /* statements just  to surpass the error of unused variable */
    // arrLocal[0] = 1;
    // arrLocal[1] = 1;
    // arrLocal[2] = arrLocal[1] + arrLocal[0];

    pgtPrint();

    exit();
}